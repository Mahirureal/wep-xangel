
export const INITIAL_PHRASES: string[] = [
    "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa",
     "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa", "I Love Calyaa",
];

export const DEFAULT_MAIN_TEXT = 'I Love You';
